# backend-hack
Proyecto Backend Hackathon

## Endpoint
* GET /users/:id - Obtener usuarios por ID
* GET /users - Obtener usuarios

* GET /applications/request - Obtener solicitudes sin aprobar 
* POST  /applications - Crear una solicitud 
* GET /applications/aproved - Obtener las solicitudes aprobadas 
* PUT /applications/:id - Aprobar o rechazar solicitud 

* GET /vendors/:id - Obtener proveedores por ID
* GET /vendors - Obtener listados de proveedores 
* POST /vendors - Crear proveedor
* PUT /vendors/:id - Actualizar stock de licencia por proveedor 

### Coleccion de postman: 

archivo: Hackaton_Backend.postman_collection.json

